package assignment1;

import java.io.Serializable;
import java.util.ArrayList;


public class Message implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ArrayList<Integer> vectorclock;
	public int sender;
	public int recipient;
	public String body;

	
	public Message(int sender, int recipient, ArrayList<Integer> vectorclock, String body) {
		this.sender = sender;
		this.recipient = recipient;
		this.vectorclock = vectorclock;
		this.body = body;
	}
	
	
}
