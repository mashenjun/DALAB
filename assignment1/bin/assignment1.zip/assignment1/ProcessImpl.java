package assignment1;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;

public class ProcessImpl extends UnicastRemoteObject implements ProcesserInterface,Runnable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private NetworkInterface NS;

	protected ProcessImpl(NetworkInterface ns) throws RemoteException {
		super();
		NS = ns;
		NS.connected();
		NS.register(this);
	}

	@Override
	public void run() {
		Scanner in = new Scanner(System.in);
		String msg;
		
		while(true) {
			try{
				msg = in.nextLine();
				NS.broadcast(msg);
				
			}
			catch (Exception e) {
				e.printStackTrace();
				in.close();
			}
		}
		
	}

	@Override
	public void sendmessage() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void reveivemessage(String s) {
		// TODO Auto-generated method stub
		System.out.println("Message: "+s);
		
	}
	
	public static void main (String[] args) {
		String url = "rmi://localhost:2000/ChatServer";
		try {
			Registry registry = LocateRegistry.getRegistry(2000);
			NetworkInterface nsi = (NetworkInterface) registry.lookup("ChatServer");
			
			new Thread(new ProcessImpl(nsi)).start();
			System.out.println("Client start");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
